char	*ft_strcapitalize(char *str)
{
	char	*mem;
	char is_first;
	char is_num;
	char is_let;

	mem = str;
	while (*str != 0)
	{
		if (*str >= 'A' && *str <= 'Z')
		{
			*str += 32;
		}
		str++;
	}
	str = mem;
	is_first = 1;
	while (*str != 0) {
		is_let = ((*str >= 'A' && *str <= 'Z') || (*str >= 'a' && *str <= 'z'));
		is_num = (*str >= '0' && *str <= '9');

		if (is_first)
		{
			
		}
		else if ()
	}
	return (mem);
}

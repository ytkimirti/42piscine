char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	while (n > 0)
	{
		*dest = *src;
		if (*src != 0)
		{
			src++;
		}
		dest++;
		n--;
	}
	return (dest);
}
